################################################################################
# MINIGAME2.RPY
# Minigame 2: "Exame clínico" — sinais compatíveis com a AIE
#
# Como funciona:
#   - O jogador examina o cavalo em 6 ÁREAS (abas à esquerda): Temperatura,
#     Mucosas, Linfonodos, Estado geral, Histórico e Hemograma.
#   - Cada área mostra 4 ACHADOS (cartas à direita). Alguns são compatíveis com
#     a AIE e outros não (distratores). A cada partida os achados são sorteados
#     de um banco maior, então o exame nunca é igual duas vezes.
#   - O jogador MARCA (clique) os achados que considera compatíveis com a AIE.
#     Clicar de novo desmarca.
#   - Só dá para concluir o exame depois de examinar TODAS as áreas.
#   - Ao concluir, entra a fase de REVISÃO: cada carta mostra se foi acerto,
#     erro ou sinal que faltou marcar, e o jogador pode navegar pelas abas para
#     ver onde errou. Depois clica em "Continuar" para voltar ao mapa.
#
# Pontuação (ver roadmap.rpy para o sistema de medalhas):
#   + MG2_POINTS_HIT   por achado compatível marcado (acerto)
#   - MG2_POINTS_MISS  por achado marcado que NÃO é compatível (erro)
#   - MG2_POINTS_MISS  por achado compatível que ficou sem marcar (faltou)
#   Achado não compatível e não marcado: neutro (0) — assim ninguém ganha
#   pontos de graça sem marcar nada. O placar nunca fica abaixo de 0.
#   Pontuação máxima = marcar exatamente todos os compatíveis.
#
# Placeholders de arte (mesmo esquema do minigame 1):
#   Se o PNG não existir em game/images/minigame2/, aparece um retângulo
#   colorido com texto, já no tamanho final. Quando você colocar o PNG com o
#   nome certo na pasta, ele passa a ser usado sozinho.
#   Todo PNG real é exibido com zoom 2.0 + nearest neighbor: exporte na METADE
#   do tamanho final indicado em cada "# IMAGEM:".
#   Os TEXTOS das abas e das cartas são desenhados pelo jogo (são muitos
#   achados), por cima de molduras que você só precisa desenhar uma vez.
#
# Este arquivo contém: dados/configuração, lógica, tela de instruções, tela
# do gameplay e o "label minigame_2_entry" — chamado pelo roadmap.rpy.
################################################################################


## -----------------------------------------------------------------------
## 1) CONFIGURAÇÃO, DADOS E LÓGICA
## -----------------------------------------------------------------------
init python:

    MG2_ART_DIR = "images/minigame2/"
    MG2_ZOOM = 2.0  # arte a 960x540, exibida em 1920x1080

    # ---- Layout (tela 1920x1080) — ajuste ao encaixar a arte ---------------
    # Abas e cartas ficam nas laterais (x 40-420 e x 1340-1880), deixando livre
    # a faixa central (x 420-1340) para a arte do fundo/cavalo.
    # Abas das áreas do exame (coluna da esquerda)
    MG2_TABS_X = 40
    MG2_TABS_Y0 = 260
    MG2_TABS_STEP = 110
    MG2_TAB_SIZE = (380, 90)         # exporte a 190x45

    # Cartas de achados (painel da direita)
    MG2_CARDS_X = 1340
    MG2_CARDS_Y0 = 280
    MG2_CARDS_STEP = 150
    MG2_CARD_SIZE = (540, 130)       # exporte a 270x65

    # Botão "Concluir exame" / "Continuar"
    MG2_SUBMIT_POS = (1340, 920)
    MG2_SUBMIT_SIZE = (540, 90)      # exporte a 270x45

    # ---- Regras ------------------------------------------------------------
    MG2_CARDS_PER_AREA = 4       # achados mostrados em cada área
    MG2_POINTS_HIT = 10          # acerto: compatível marcado
    MG2_POINTS_MISS = 5          # erro: perde isto (marcou errado OU deixou de marcar)

    # ---- Banco de achados por área -----------------------------------------
    # "correct"   = achados COMPATÍVEIS com a AIE (vêm da sua lista de sinais).
    # "wrong"     = distratores (NÃO compatíveis) — inventei estes; revise!
    # "n_correct" = quantos compatíveis aparecem por partida (sorteados do
    #               banco "correct"). O resto das 4 cartas vem de "wrong".
    #               Precisa de len(wrong) >= 4 - n_correct.
    MG2_AREAS = [
        {
            "label": _("Temperatura"),
            "correct": [_("Febre (temperatura elevada)"),
                        _("Febre em episódios recorrentes")],
            "wrong": [_("Hipotermia (temperatura baixa)"),
                      _("Temperatura sempre abaixo do normal"),
                      _("Calafrios com temperatura baixa")],
            "n_correct": 2,
        },
        {
            "label": _("Mucosas"),
            "correct": [_("Mucosas pálidas"),
                        _("Petéquias nas mucosas")],
            "wrong": [_("Mucosas rosadas e úmidas"),
                      _("Mucosas cianóticas (azuladas)"),
                      _("Mucosas congestas e muito avermelhadas")],
            "n_correct": 2,
        },
        {
            "label": _("Linfonodos"),
            "correct": [_("Linfonodos aumentados")],
            "wrong": [_("Linfonodos com abscesso drenando"),
                      _("Linfonodos atrofiados"),
                      _("Ausência de qualquer alteração palpável")],
            "n_correct": 1,
        },
        {
            "label": _("Estado geral"),
            "correct": [_("Letargia"),
                        _("Fraqueza"),
                        _("Perda de peso"),
                        _("Queda de desempenho")],
            "wrong": [_("Hiperexcitabilidade e agitação"),
                      _("Ganho de peso acentuado"),
                      _("Desempenho acima do esperado")],
            "n_correct": 2,
        },
        {
            "label": _("Histórico"),
            "correct": [_("Febre recorrente"),
                        _("Exposição a sangue (agulhas ou instrumentos)"),
                        _("Contato com insetos hematófagos"),
                        _("Contato com animais infectados")],
            "wrong": [_("Vacinação em dia, sem outros achados"),
                      _("Animal isolado, sem insetos nem outros equídeos"),
                      _("Cólica leve resolvida há semanas")],
            "n_correct": 2,
        },
        {
            "label": _("Hemograma"),
            "correct": [_("Anemia"),
                        _("Hemoglobina (Hb) baixa"),
                        _("Hematócrito (Ht) baixo"),
                        _("Trombocitopenia (plaquetas baixas)")],
            "wrong": [_("Policitemia (Ht alto)"),
                      _("Hemoglobina (Hb) acima do normal"),
                      _("Plaquetas muito aumentadas")],
            "n_correct": 2,
        },
    ]

    # ---- Placeholders de arte ----------------------------------------------
    def mg2_art(filename, size, label, color):
        """Imagem real (ampliada 2x, nearest neighbor; exporte na metade de
        "size") se o arquivo existir, senão um retângulo colorido com texto
        já no tamanho final."""
        path = MG2_ART_DIR + filename
        if renpy.loadable(path):
            return mg_canvas_art(path)
        return Fixed(
            Solid(color, xysize=size),
            Text(label, size=26, color="#ffffff", xalign=0.5, yalign=0.5,
                 text_align=0.5, xmaximum=size[0] - 20),
            xysize=size,
        )

    # IMAGEM: minigame2/mg2_bg.png — fundo cheio: baia/consultório com o cavalo.
    # Tamanho final: 1920x1080 → exporte a 960x540. (Deixe livre a coluna da
    # esquerda para as abas e a da direita para as cartas.)
    MG2_BG = mg2_art("mg2_bg.png", (1920, 1080), "FUNDO: cavalo em exame\n(mg2_bg.png)", "#2f3a3a")

    # IMAGEM: minigame2/mg2_title_panel.png — painel de título (canto superior
    # esquerdo). Tamanho final: 820x170 → exporte a 410x85.
    MG2_TITLE_PANEL = mg2_art("mg2_title_panel.png", (820, 170), "PAINEL DE TÍTULO\n(mg2_title_panel.png)", "#4a3a20")

    # IMAGEM: minigame2/mg2_tab_idle.png e mg2_tab_active.png — moldura da aba
    # de uma área (o nome da área é escrito pelo jogo por cima).
    # Tamanho final: 520x100 → exporte a 260x50.
    MG2_TAB_ART = {
        "idle": mg2_art("mg2_tab_idle.png", MG2_TAB_SIZE, "", "#4a4a4a"),
        "active": mg2_art("mg2_tab_active.png", MG2_TAB_SIZE, "", "#2c6e8a"),
    }

    # IMAGEM: minigame2/mg2_card_<estado>.png — moldura de uma carta de achado
    # (o texto do achado é escrito pelo jogo por cima). Tamanho final: 820x130
    # → exporte a 410x65. Estados:
    #   idle     = não marcada            selected = marcada (antes de concluir)
    #   right    = marcada e correta      wrong    = marcada e ERRADA
    #   missed   = compatível que faltou marcar (mostrada só na revisão)
    MG2_CARD_COLORS = {
        "idle": "#4a4a4a", "selected": "#2c6e8a", "right": "#2e7d32",
        "wrong": "#8a2c2c", "missed": "#9a7a1c",
    }
    MG2_CARD_ART = dict(
        (state, mg2_art("mg2_card_%s.png" % state, MG2_CARD_SIZE, "", color))
        for state, color in MG2_CARD_COLORS.items()
    )

    # IMAGEM: minigame2/mg2_submit_idle.png, mg2_submit_hover.png,
    # mg2_submit_disabled.png — botão "Concluir exame". Tamanho final: 400x90
    # → exporte a 200x45. (o texto é escrito pelo jogo por cima)
    MG2_SUBMIT_IDLE = mg2_art("mg2_submit_idle.png", MG2_SUBMIT_SIZE, "", "#3a5a3a")
    MG2_SUBMIT_HOVER = mg2_art("mg2_submit_hover.png", MG2_SUBMIT_SIZE, "", "#4f7a4f")
    MG2_SUBMIT_DISABLED = mg2_art("mg2_submit_disabled.png", MG2_SUBMIT_SIZE, "", "#2a2a2a")

    # ---- Efeitos sonoros (só tocam se o arquivo existir) -------------------
    def mg2_sfx(kind):
        files = {
            "hover": "audio/sfx_hover.ogg",
            "click": "audio/sfx_click.ogg",
            "correct": "audio/sfx_correct.ogg",
            "wrong": "audio/sfx_wrong.ogg",
        }
        path = files.get(kind)
        if path and renpy.loadable(path):
            renpy.sound.play(path)


## Estado do minigame (guardado no save / rollback)
default mg2_cards = []        # por área: lista de {"text": ..., "correct": bool}
default mg2_selected = []     # por área: lista de bool (carta marcada?)
default mg2_visited = []      # por área: já foi examinada?
default mg2_area = 0          # área aberta agora
default mg2_phase = "exam"    # "exam" (jogando) ou "review" (revisão após concluir)
default mg2_score = 0
default mg2_max_score = 0


init python:

    def mg2_reset():
        """Nova partida: sorteia os achados de cada área e zera as marcações."""
        cards = []
        for area in MG2_AREAS:
            correct_pool = list(area["correct"])
            wrong_pool = list(area["wrong"])
            renpy.random.shuffle(correct_pool)
            renpy.random.shuffle(wrong_pool)

            n_correct = area["n_correct"]
            area_cards = [{"text": t, "correct": True} for t in correct_pool[:n_correct]]
            area_cards += [{"text": t, "correct": False}
                           for t in wrong_pool[:MG2_CARDS_PER_AREA - n_correct]]
            renpy.random.shuffle(area_cards)
            cards.append(area_cards)

        store.mg2_cards = cards
        store.mg2_selected = [[False] * len(c) for c in cards]
        store.mg2_visited = [False] * len(cards)
        store.mg2_visited[0] = True
        store.mg2_area = 0
        store.mg2_phase = "exam"
        store.mg2_score = 0
        store.mg2_max_score = sum(1 for c in cards for card in c if card["correct"]) * MG2_POINTS_HIT

    def mg2_select_area(i):
        """Abre a área i (e a marca como examinada)."""
        store.mg2_area = i
        store.mg2_visited[i] = True
        mg2_sfx("click")

    def mg2_next():
        """Avança para a próxima área (sem voltar)."""
        if store.mg2_phase != "exam" or store.mg2_area >= len(MG2_AREAS) - 1:
            return
        store.mg2_area += 1
        store.mg2_visited[store.mg2_area] = True
        mg2_sfx("click")

    def mg2_toggle(area, j):
        """Marca/desmarca a carta j da área. Travado na fase de revisão."""
        if store.mg2_phase != "exam":
            return
        store.mg2_selected[area][j] = not store.mg2_selected[area][j]
        mg2_sfx("click")

    def mg2_all_visited():
        return all(store.mg2_visited)

    def mg2_marked_count(area):
        return sum(1 for s in store.mg2_selected[area] if s)

    def mg2_card_state(area, j):
        """Estado visual da carta: idle/selected (jogando) ou
        right/wrong/missed (revisão)."""
        selected = store.mg2_selected[area][j]
        correct = store.mg2_cards[area][j]["correct"]
        if store.mg2_phase == "exam":
            return "selected" if selected else "idle"
        if selected and correct:
            return "right"
        if selected and not correct:
            return "wrong"
        if correct:
            return "missed"
        return "idle"

    def mg2_submit():
        """Conclui o exame: calcula a pontuação e entra na fase de revisão."""
        if store.mg2_phase != "exam" or store.mg2_area < len(MG2_AREAS) - 1:
            return
        score = 0
        for area in range(len(store.mg2_cards)):
            for j, card in enumerate(store.mg2_cards[area]):
                selected = store.mg2_selected[area][j]
                if card["correct"]:
                    score += MG2_POINTS_HIT if selected else -MG2_POINTS_MISS
                elif selected:
                    score -= MG2_POINTS_MISS
        store.mg2_score = max(0, score)
        store.mg2_phase = "review"
        store.mg2_area = 0
        mg2_build_review()
        mg2_sfx("correct" if store.mg2_score >= store.mg2_max_score else "wrong")

    def mg2_build_review():
        """Revisão final: cada achado, o que o jogador fez e se isso estava certo.
        Linha de cima = o achado. Linha de baixo = "você marcou / não marcou" e a
        verdade (é ou não é compatível com a AIE)."""
        mg_review_clear()
        for area, info in enumerate(MG2_AREAS):
            cards = store.mg2_cards[area]
            right = 0
            for j, card in enumerate(cards):
                if store.mg2_selected[area][j] == card["correct"]:
                    right += 1
            mg_review_group(_("%s: %d de %d decisões certas") % (info["label"], right, len(cards)))
            for j, card in enumerate(cards):
                selected = store.mg2_selected[area][j]
                text = card["text"]
                if card["correct"] and selected:
                    mg_review_add("ok", text, _("Você marcou. Certo: é compatível com a AIE."))
                elif card["correct"]:
                    mg_review_add("miss", text, _("Você NÃO marcou, mas é compatível com a AIE: devia ter marcado."))
                elif selected:
                    mg_review_add("bad", text, _("Você marcou, mas NÃO é compatível com a AIE."))
                else:
                    mg_review_add("ok", text, _("Você não marcou. Certo: não é compatível com a AIE."))

    def mg2_verdict():
        """Frase de feedback conforme o desempenho."""
        ratio = float(store.mg2_score) / max(1, store.mg2_max_score)
        if ratio >= 1.0:
            return _("Exame perfeito! Todos os sinais de AIE foram identificados.")
        elif ratio >= 0.7:
            return _("Bom exame! Mas alguns sinais passaram despercebidos.")
        else:
            return _("Revise os sinais clínicos da AIE e tente de novo.")


## -----------------------------------------------------------------------
## 1.5) TELA DE INSTRUÇÕES
##    Uso: call screen minigame2_instructions
##    Modal: bloqueia qualquer clique no que estiver atrás até "Entendi".
## -----------------------------------------------------------------------
init python:

    # IMAGEM: minigame2/mg2_instructions_bg.png — fundo cheio das instruções.
    # Tamanho final: 1920x1080 → exporte o PNG a 960x540.
    MG2_INSTR_BG = mg2_art("mg2_instructions_bg.png", (1920, 1080),
                           "FUNDO: instruções\n(mg2_instructions_bg.png)", "#2a2418")

    # IMAGEM: minigame2/mg2_instructions_panel.png — moldura do texto de regras.
    # Tamanho final: 1200x600 → exporte o PNG a 600x300.
    MG2_INSTR_PANEL = mg2_art("mg2_instructions_panel.png", (1200, 600),
                              "MOLDURA DE TEXTO\n(mg2_instructions_panel.png)", "#4a3a20")

init python:

    MG2_CLOSE_IDLE = mg2_art("mg2_close_idle.png", (240, 80), "ENTENDI\n(mg2_close_idle.png)", "#3a5a3a")
    MG2_CLOSE_HOVER = mg2_art("mg2_close_hover.png", (240, 80), "ENTENDI\n(mg2_close_hover.png)", "#4f7a4f")

    # Miniatura para o tutorial (mesma arte, estado inicial, a 40%)
    _l = [MG2_BG,
          mg_tut_at(MG2_TITLE_PANEL, 60, 40),
          mg_tut_text(_("2 - EXAME CLÍNICO"), 90, 65, size=34),
          mg_tut_text(_("Examine uma área de cada vez e marque os achados compatíveis com a AIE."), 90, 135, size=24)]
    for _i, _area in enumerate(MG2_AREAS):
        _y = MG2_TABS_Y0 + _i * MG2_TABS_STEP
        _l.append(mg_tut_at(MG2_TAB_ART["active" if _i == 0 else "idle"], MG2_TABS_X, _y))
        _l.append(mg_tut_text(_area["label"], MG2_TABS_X + 30, _y + 28, size=30))
    _l.append(mg_tut_text(MG2_AREAS[0]["label"], MG2_CARDS_X, 200, size=44, bold=True))
    _l.append(mg_tut_text(_("Marque TODOS os compatíveis (pode ser mais de um)"), MG2_CARDS_X, 252, size=20))
    _ex = [MG2_AREAS[0]["correct"][0], MG2_AREAS[0]["wrong"][0], MG2_AREAS[0]["correct"][1], MG2_AREAS[0]["wrong"][1]]
    for _j, _t in enumerate(_ex):
        _y = MG2_CARDS_Y0 + _j * MG2_CARDS_STEP
        _l.append(mg_tut_at(MG2_CARD_ART["idle"], MG2_CARDS_X, _y))
        _l.append(mg_tut_text(_t, MG2_CARDS_X + 40, _y + 45, size=28))
    _l.append(mg_tut_at(MG2_SUBMIT_IDLE, MG2_SUBMIT_POS[0], MG2_SUBMIT_POS[1]))
    _l.append(mg_tut_text(_("Continuar"), MG2_SUBMIT_POS[0] + 190, MG2_SUBMIT_POS[1] + 28, size=32))
    MG2_TUTORIAL_PREVIEW = mg_tut_preview(_l)

style mg2_instructions_text:
    xalign 0.5
    yalign 0.5
    text_align 0.5
    color MG_INSTR_TEXT_COLOR
    size 30
    xsize 1000


screen minigame2_instructions():

    use mg_tutorial(MG2_INSTR_BG,
        _("Um cavalo chegou para exame clínico!"),
        MG2_TUTORIAL_PREVIEW,
        [(395, 305), (1860, 420), (1860, 965)],
        [_("Comece pela Temperatura e avance uma área de cada vez."),
         _("Marque TODOS os achados compatíveis com a AIE (pode ser mais de um)."),
         _("Ao terminar a área, clique em CONTINUAR (na última: CONCLUIR).")],
        _("Não dá para voltar a uma área depois de continuar. Clique de novo num achado para desmarcar. Achado certo marcado dá pontos; achado errado marcado, ou sinal da doença esquecido, tira pontos."),
        MG2_CLOSE_IDLE, MG2_CLOSE_HOVER, (0.5, 0.85))


## -----------------------------------------------------------------------
## 2) TELA DO MINIGAME
## -----------------------------------------------------------------------
screen minigame2_gameplay():

    modal True  # bloqueia qualquer interação com o que estiver atrás

    add MG2_BG

    # ---- Painel de título / objetivo (canto superior esquerdo) ----------
    # Se a sua arte do painel já tiver o texto desenhado, apague os 2 textos abaixo.
    fixed:
        pos (60, 40)
        xysize (820, 170)
        add MG2_TITLE_PANEL
        text _("2 - EXAME CLÍNICO"):
            xpos 30
            ypos 25
            size 34
            color "#ffffff"
        text _("Examine uma área de cada vez e marque os achados compatíveis com a AIE."):
            xpos 30
            ypos 95
            size 24
            color "#ffffff"
            xmaximum 760

    # ---- Etapas: as 6 áreas do exame (só indicam o progresso) ------------
    for i, area in enumerate(MG2_AREAS):

        $ tab_label = area["label"]
        $ tab_art = MG2_TAB_ART["active"] if i == mg2_area else MG2_TAB_ART["idle"]
        $ tab_marked = mg2_marked_count(i)

        fixed:
            pos (MG2_TABS_X, MG2_TABS_Y0 + i * MG2_TABS_STEP)
            xysize MG2_TAB_SIZE
            at Transform(alpha=(0.45 if i > mg2_area else 1.0))
            add tab_art
            text "[tab_label!t]":
                xpos 30
                yalign 0.5
                size 30
                color "#ffffff"
            # "✓" = área já concluída
            if i < mg2_area:
                text "✓ [tab_marked]":
                    xalign 0.96
                    yalign 0.5
                    size 26
                    color "#ffffff"

    # ---- Cartas de achados da área aberta --------------------------------
    $ area_label = MG2_AREAS[mg2_area]["label"]

    text "[area_label!t]":
        xpos MG2_CARDS_X
        ypos 200
        size 44
        bold True
        color "#ffffff"
        outlines [(3, "#2a1a0c", 0, 0)]

    $ area_step = mg2_area + 1
    $ area_total = len(MG2_AREAS)
    text _("Área [area_step] de [area_total]"):
        xpos MG2_CARDS_X + MG2_CARD_SIZE[0]
        xanchor 1.0
        ypos 214
        size 28
        color "#ffffff"
        outlines [(3, "#2a1a0c", 0, 0)]

    text _("Marque TODOS os compatíveis (pode ser mais de um)"):
        xpos MG2_CARDS_X
        ypos 252
        xmaximum 560
        size 20
        color "#ffe9a8"
        outlines [(3, "#2a1a0c", 0, 0)]

    for j, card in enumerate(mg2_cards[mg2_area]):

        $ card_text = card["text"]
        $ card_state = mg2_card_state(mg2_area, j)

        button:
            pos (MG2_CARDS_X, MG2_CARDS_Y0 + j * MG2_CARDS_STEP)
            xysize MG2_CARD_SIZE
            background None
            focus_mask True
            action Function(mg2_toggle, mg2_area, j)
            hovered Function(mg2_sfx, "hover")
            add MG2_CARD_ART[card_state]
            text "[card_text!t]":
                xpos 40
                yalign 0.5
                size 28
                color "#ffffff"
                xmaximum MG2_CARD_SIZE[0] - 60

    # ---- Rodapé: concluir (jogando) ou resultado + continuar (revisão) ---
    if mg2_phase == "exam":

        $ last_area = (mg2_area >= len(MG2_AREAS) - 1)

        imagebutton:
            pos MG2_SUBMIT_POS
            idle MG2_SUBMIT_IDLE
            hover MG2_SUBMIT_HOVER
            focus_mask True
            action ([Function(mg2_submit), Return(True)] if last_area else Function(mg2_next))
            hovered Function(mg2_sfx, "hover")

        $ footer_label = _("Concluir exame") if last_area else _("Continuar")

        text "[footer_label!t]":
            pos (MG2_SUBMIT_POS[0] + MG2_SUBMIT_SIZE[0] // 2, MG2_SUBMIT_POS[1] + MG2_SUBMIT_SIZE[1] // 2)
            anchor (0.5, 0.5)
            size 32
            color "#ffffff"
            outlines [(3, "#2a1a0c", 0, 0)]


## -----------------------------------------------------------------------
## 3) LABEL DO GAMEPLAY (motor do minigame em si)
## -----------------------------------------------------------------------
label minigame_2_gameplay:

    $ quick_menu = False       # esconde os botões rápidos do rodapé durante o minigame
    $ renpy.block_rollback()   # impede que o rollback (roda do mouse) bagunce o estado
    $ mg2_reset()              # sorteia os achados (permite rejogar do zero)

    scene black
    call screen minigame2_gameplay   # só retorna quando o jogador clica em "Continuar"

    $ quick_menu = True
    return


## -----------------------------------------------------------------------
## 4) PONTO DE ENTRADA (chamado pelo roadmap.rpy: "call expression 'minigame_2_entry'")
##    Mostra as instruções, roda o gameplay e avisa o mapa que terminou.
## -----------------------------------------------------------------------
label minigame_2_entry:

    call screen minigame2_instructions

    $ mg_again = True
    while mg_again:
        call minigame_2_gameplay from _mg2_gameplay_call

        $ mg_report_score(2, mg2_score, mg2_max_score)  # registra o placar e a medalha, se for o caso
        $ mg_complete(2)                                 # marca como concluído e libera o 3

        call screen mg_result(mg2_score, mg2_max_score, mg2_verdict())
        $ mg_again = (_return == "replay")

    return
