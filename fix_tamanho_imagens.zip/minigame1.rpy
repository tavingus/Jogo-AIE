################################################################################
# MINIGAME1.RPY
# Minigame 1: "Taxonomia e identificação do vírus" (AIE / EIAV)
#
# Como funciona:
#   - Esquerda: clicar na imagem troca a MORFOLOGIA (5 opções, só 1 correta).
#   - Direita: cada categoria taxonômica é um botão; cada clique passa para a
#     próxima opção, em ciclo. Cada opção é uma imagem própria (desenhada no
#     Aseprite, com o texto já embutido) — nenhum texto é desenhado pelo jogo.
#   - O minigame termina quando a morfologia E todas as categorias estão certas.
#
# Placeholders de arte:
#   Se o arquivo de imagem NÃO existir em game/images/minigame1/, o jogo mostra
#   automaticamente um retângulo colorido com texto no lugar. Quando você
#   colocar o PNG com o nome certo na pasta, ele passa a ser usado sozinho —
#   não precisa mexer no código.
#
# Pixel art (mesmo esquema do menu principal):
#   Todo PNG real é exibido com zoom 2.0 + nearest neighbor (ver MG1_ZOOM),
#   então cada arquivo deve ser exportado na METADE do tamanho final indicado
#   nos comentários "# IMAGEM:" abaixo. O placeholder já aparece no tamanho
#   final, sem zoom, então nunca fica maior/menor que a arte real.
#
# Este arquivo contém: dados/configuração, funções de lógica, a tela de
# instruções, a screen do gameplay e o "label minigame_1_entry" — o ponto de
# entrada chamado pelo roadmap.rpy quando o jogador clica no nó 1 do mapa.
################################################################################


## -----------------------------------------------------------------------
## 1) CONFIGURAÇÃO, DADOS E LÓGICA
## -----------------------------------------------------------------------
init python:

    # ---- Pasta das artes ------------------------------------------------
    MG1_ART_DIR = "images/minigame1/"

    # ---- Pixel art: mesmo esquema do menu principal (arte a 960x540, ------
    # ---- exibida em 1920x1080 com zoom 2.0 + nearest neighbor) ----------
    # Todo PNG real (não placeholder) deve ser exportado na METADE do
    # tamanho final que ele ocupa na tela — o jogo aplica o zoom sozinho.
    # Ex.: um botão que ocupa 460x72 na tela final deve ser desenhado/exportado
    # a 230x36. O placeholder (enquanto o arquivo não existe) já aparece no
    # tamanho final, sem precisar de zoom.
    MG1_ZOOM = 2.0

    # ---- Posições e tamanhos (tela 1920x1080) — ajuste ao encaixar a arte --
    # Imagem de morfologia (página esquerda do livro). Suas PNGs são canvas
    # cheio (o vírus já vem posicionado dentro do canvas), então aqui NÃO
    # aplicamos nenhum deslocamento extra — a imagem cobre a tela toda e
    # o focus_mask garante que só os pixels coloridos do vírus respondem ao clique.
    MG1_MORPH_POS = (0, 0)
    MG1_MORPH_SIZE = (1920, 1080)

    # Linhas de categorias (página direita do livro).
    # ATENÇÃO: estas 4 constantes só posicionam os PLACEHOLDERS e a marca de
    # teste. A arte real das opções é canvas inteiro
    # (960x540, já na posição certa) e IGNORA estes valores. Os nomes das
    # categorias ("Ordem", "Família"...) já estão desenhados no fundo.
    # (valores ajustados às linhas do livro: ~87 px entre elas, caixa dentro da
    #  página da direita, logo depois dos nomes das categorias)
    MG1_ROWS_Y0 = 286          # y da primeira linha
    MG1_ROWS_STEP = 87         # distância vertical entre linhas
    MG1_BTN_X = 1232           # x do placeholder que mostra a opção atual
    MG1_BTN_SIZE = (290, 60)   # tamanho do placeholder de cada opção

    # ---- Pontuação (sem timers) -----------------------------------------
    # O jogador monta as 7 respostas (morfologia + 6 categorias) e clica em
    # CONCLUIR. Cada resposta certa vale MG1_POINTS_HIT pontos; não há erro por
    # "tirar do lugar" nem rodada que falha. Acertar as 7 = pontuação máxima
    # (medalha). No fim, a revisão mostra o que acertou e errou, com a resposta.
    MG1_POINTS_HIT = 10
    MG1_MAX_SCORE = MG1_POINTS_HIT * (1 + 6)   # morfologia + 6 categorias (ajustado abaixo)

    # ---- Morfologia -----------------------------------------------------
    # Arquivos em game/images/minigame1/ (a ordem é a ordem do ciclo de cliques)
    MG1_MORPH_FILES = [
        "morfologia_1.png",
        "morfologia_2.png",
        "morfologia_3.png",
        "morfologia_4.png",
        "morfologia_5.png",
    ]
    MG1_MORPH_CORRECT = 2  # índice (começa em 0) da morfologia correta => morfologia_3.png
    # Descrição da morfologia certa (aparece na revisão final). Edite conforme
    # a sua arte. Se ficar None, a revisão diz só o número da imagem.
    MG1_MORPH_NAME = None
    # Nome de cada linha de categoria (mesma ordem de MG1_CATEGORIES), para a revisão.
    MG1_CAT_NAMES = [_("Ordem"), _("Família"), _("Subfamília"), _("Gênero"), _("Espécie"), _("Espécies afetadas")]

    # ---- Categorias taxonômicas ----------------------------------------
    # Cada opção é uma imagem própria (desenhada no Aseprite, já com o texto
    # embutido), em CANVAS INTEIRO 960x540 com a opção já na posição da linha.
    # O nome da categoria ("Ordem", "Família"...) fica no fundo (mg1_bg.png).
    #
    # "files"        = nome dos 5 arquivos PNG, um por opção, nesta ordem.
    # "options_debug" = só o texto que aparece no retângulo placeholder
    #                    enquanto o arquivo .png correspondente não existe
    #                    (não aparece mais quando a arte real estiver lá).
    # "correct"      = índice (começa em 0) da opção certa.
    # (a ordem das categorias aqui é a ordem das linhas na tela)
    MG1_CATEGORIES = [
        {
            "files": ["cat_ordem_1.png", "cat_ordem_2.png", "cat_ordem_3.png", "cat_ordem_4.png", "cat_ordem_5.png"],
            "options_debug": ["Mononegavirales", "Nidovirales", "Ortervirales", "Picornavirales", "Herpesvirales"],
            "correct": 2,
        },
        {
            "files": ["cat_familia_1.png", "cat_familia_2.png", "cat_familia_3.png", "cat_familia_4.png", "cat_familia_5.png"],
            "options_debug": ["Paramyxoviridae", "Flaviviridae", "Herpesviridae", "Retroviridae", "Coronaviridae"],
            "correct": 3,
        },
        {
            "files": ["cat_subfamilia_1.png", "cat_subfamilia_2.png", "cat_subfamilia_3.png", "cat_subfamilia_4.png", "cat_subfamilia_5.png"],
            "options_debug": ["Orthoparamyxovirinae", "Spumaretrovirinae", "Orthoretrovirinae", "Orthocoronavirinae", "Alphaherpesvirinae"],
            "correct": 2,
        },
        {
            "files": ["cat_genero_1.png", "cat_genero_2.png", "cat_genero_3.png", "cat_genero_4.png", "cat_genero_5.png"],
            "options_debug": ["Morbillivirus", "Alpharetrovirus", "Deltaretrovirus", "Lentivirus", "Betaretrovirus"],
            "correct": 3,
        },
        {
            "files": ["cat_especie_1.png", "cat_especie_2.png", "cat_especie_3.png", "cat_especie_4.png", "cat_especie_5.png"],
            "options_debug": ["Equine arteritis virus", "West Nile virus", "Equine infectious anemia virus", "Equine influenza virus", "Human immunodeficiency virus 1"],
            "correct": 2,
        },
        {
            "files": ["cat_afetadas_1.png", "cat_afetadas_2.png", "cat_afetadas_3.png", "cat_afetadas_4.png", "cat_afetadas_5.png"],
            "options_debug": ["Equídeos e bovinos", "Equídeos e suínos", "Equídeos e humanos", "Todos os mamíferos", "Apenas equídeos"],
            "correct": 4,
        },
    ]
    MG1_MAX_SCORE = MG1_POINTS_HIT * (1 + len(MG1_CATEGORIES))

    # ---- Placeholders de arte ------------------------------------------
    def mg1_art(filename, size, label, color):
        """Devolve a imagem real (se o arquivo existir), já ampliada 2x com
        nearest neighbor (igual ao menu principal — a arte deve ser exportada
        na metade de "size"), ou um retângulo colorido com texto (placeholder)
        já no tamanho final indicado, caso o arquivo ainda não exista."""
        path = MG1_ART_DIR + filename
        if renpy.loadable(path):
            return mg_canvas_art(path)
        return Fixed(
            Solid(color, xysize=size),
            Text(label, size=28, color="#ffffff", xalign=0.5, yalign=0.5,
                 text_align=0.5, xmaximum=size[0] - 20),
            xysize=size,
        )

    def mg1_full_art(filename, rect, label, color):
        """Arte de CANVAS INTEIRO (960x540 → 1920x1080, nearest neighbor,
        desenhada em (0, 0), sem usar posição do código) se o PNG existir.
        Senão, um placeholder: retângulo colorido com texto na posição
        "rect" = (x, y, largura, altura), dentro de um canvas transparente
        de 1920x1080 (assim ele se comporta igual à arte real)."""
        path = MG1_ART_DIR + filename
        if renpy.loadable(path):
            return mg_canvas_art(path)
        x, y, w, h = rect
        box = Fixed(
            Solid(color, xysize=(w, h)),
            Text(label, size=28, color="#ffffff", xalign=0.5, yalign=0.5,
                 text_align=0.5, xmaximum=w - 20),
            xysize=(w, h),
        )
        return Fixed(Transform(box, pos=(x, y)), xysize=(1920, 1080))

    def mg1_build_morph_art():
        """Monta a lista de displayables das 5 morfologias (arte real ou placeholder)."""
        colors = ["#7a3b3b", "#3b6a7a", "#5b7a3b", "#6a3b7a", "#7a6a3b"]
        result = []
        for i, filename in enumerate(MG1_MORPH_FILES):
            result.append(mg1_art(filename, MG1_MORPH_SIZE,
                                  "MORFOLOGIA %d\n(%s)" % (i + 1, filename),
                                  colors[i % len(colors)]))
        return result

    def mg1_build_category_art(cat, row):
        """Monta a lista de displayables das 5 opções da categoria da linha
        "row" (arte real de canvas inteiro, com texto já desenhado no Aseprite,
        ou placeholder na posição da linha enquanto o arquivo não existir)."""
        colors = ["#2c4a63", "#3a5a3a", "#5a3a4a", "#5a4a2a", "#3a3a5a"]
        rect = (MG1_BTN_X, MG1_ROWS_Y0 + row * MG1_ROWS_STEP, MG1_BTN_SIZE[0], MG1_BTN_SIZE[1])
        result = []
        for i, filename in enumerate(cat["files"]):
            label = "%s\n(%s)" % (cat["options_debug"][i], filename)
            result.append(mg1_full_art(filename, rect, label, colors[i % len(colors)]))
        return result

    # IMAGEM: minigame1/mg1_bg.png — fundo cheio: livro aberto, mesa, cenário.
    # Tamanho final na tela: 1920x1080 → exporte o PNG a 960x540 (a arte
    # é ampliada 2x automaticamente).
    MG1_BG = mg1_art("mg1_bg.png", (1920, 1080), "FUNDO: livro aberto\n(mg1_bg.png)", "#3b2a1a")

    # IMAGEM: minigame1/mg1_title_panel.png — painel de título no canto superior
    # esquerdo. CANVAS INTEIRO 960x540, com o painel já na posição dele (o
    # retângulo (60, 40, 820, 170) abaixo só posiciona o placeholder).
    MG1_TITLE_PANEL = mg1_full_art("mg1_title_panel.png", (60, 40, 820, 170), "PAINEL DE TÍTULO\n(mg1_title_panel.png)", "#5a3a1c")

    # IMAGEM: minigame1/morfologia_1.png ... morfologia_5.png — imagens que alternam
    # na página esquerda (uma delas é a correta, definida em MG1_MORPH_CORRECT).
    # Tamanho final: 700x700 → exporte cada PNG a 350x350.
    MG1_MORPH_ART = mg1_build_morph_art()

    # IMAGEM: minigame1/cat_<categoria>_1.png ... cat_<categoria>_5.png — as 5
    # opções de CADA categoria (ordem, familia, subfamilia, genero, especie,
    # afetadas), já com o texto da opção desenhado na própria arte.
    # Cada PNG é um CANVAS INTEIRO de 960x540 com a opção já na posição da
    # linha dela (como a morfologia): o jogo amplia 2x e desenha em (0, 0), e
    # focus_mask True faz só os pixels opacos responderem ao clique.
    # O nome da categoria NÃO é desenhado pelo jogo (está no fundo).
    # Nenhum texto é desenhado por cima pelo jogo, nem existe estado de hover
    # separado — o clique só alterna entre as 5 imagens (igual à morfologia).
    MG1_CATEGORY_ART = [mg1_build_category_art(cat, row) for row, cat in enumerate(MG1_CATEGORIES)]

    # IMAGEM: minigame1/mg1_success.png — selo/banner exibido ao acertar tudo.
    # CANVAS INTEIRO 960x540, com o selo já na posição dele (o retângulo
    # (510, 390, 900, 300) só posiciona o placeholder, no centro da tela).
    MG1_SUCCESS = mg1_full_art("mg1_success.png", (510, 390, 900, 300), "CLASSIFICAÇÃO CORRETA!\n(mg1_success.png)", "#2e7d32")

    # IMAGEM: minigame1/mg1_fail.png — banner exibido quando o jogador erra
    # demais (4 erros ou mais). CANVAS INTEIRO 960x540, banner já na posição
    # (o retângulo (510, 390, 900, 300) só posiciona o placeholder).
    MG1_FAIL = mg1_full_art("mg1_fail.png", (510, 390, 900, 300), "MUITOS ERROS!\nTente de novo\n(mg1_fail.png)", "#8a2c2c")

    # IMAGEM: minigame1/mg1_concluir_idle.png e mg1_concluir_hover.png — botão
    # "Concluir" (texto desenhado), embaixo da página direita do livro. CANVAS
    # INTEIRO 960x540, botão já na posição (o retângulo só posiciona o placeholder).
    MG1_CONCLUDE_RECT = (1232, 936, 290, 72)
    MG1_CONCLUDE_IDLE = mg1_full_art("mg1_concluir_idle.png", MG1_CONCLUDE_RECT, "CONCLUIR\n(mg1_concluir_idle.png)", "#3a5a3a")
    MG1_CONCLUDE_HOVER = mg1_full_art("mg1_concluir_hover.png", MG1_CONCLUDE_RECT, "CONCLUIR\n(mg1_concluir_hover.png)", "#4f7a4f")

    # ---- Efeitos sonoros (só tocam se o arquivo existir) ---------------
    def mg1_sfx(kind):
        # AUDIO: audio/sfx_hover.ogg, audio/sfx_click.ogg (já usados no menu)
        # AUDIO: audio/sfx_win.ogg — som de acerto final (opcional)
        files = {
            "hover": "audio/sfx_hover.ogg",
            "click": "audio/sfx_click.ogg",
            "win": "audio/sfx_win.ogg",
            "wrong": "audio/sfx_wrong.ogg",
        }
        path = files.get(kind)
        if path and renpy.loadable(path):
            renpy.sound.play(path)


## Estado do minigame (guardado no save / rollback)
default mg1_morph_index = 0   # morfologia atualmente exibida
default mg1_cat_indices = []  # opção atual de cada categoria (mesma ordem de MG1_CATEGORIES)


init python:

    def mg1_reset():
        """Prepara uma nova partida: sorteia um ponto de partida ERRADO para
        a morfologia e para cada categoria (o jogador nunca começa já certo)."""
        global mg1_morph_index, mg1_cat_indices

        wrong_morphs = [i for i in range(len(MG1_MORPH_FILES)) if i != MG1_MORPH_CORRECT]
        mg1_morph_index = renpy.random.choice(wrong_morphs)

        mg1_cat_indices = []
        for cat in MG1_CATEGORIES:
            wrong = [i for i in range(len(cat["files"])) if i != cat["correct"]]
            mg1_cat_indices.append(renpy.random.choice(wrong))

    def mg1_is_correct(i):
        """A categoria de índice i está na opção certa?"""
        return mg1_cat_indices[i] == MG1_CATEGORIES[i]["correct"]

    def mg1_hits():
        """Quantas das respostas (morfologia + categorias) estão certas."""
        n = 1 if mg1_morph_index == MG1_MORPH_CORRECT else 0
        for i in range(len(MG1_CATEGORIES)):
            if mg1_is_correct(i):
                n += 1
        return n

    def mg1_score():
        """Pontuação desta rodada: 10 pontos por resposta certa."""
        return mg1_hits() * MG1_POINTS_HIT

    def mg1_verdict():
        """Frase final conforme o desempenho."""
        total = 1 + len(MG1_CATEGORIES)
        hits = mg1_hits()
        if hits == total:
            return _("Perfeito! Você identificou o vírus da AIE corretamente.")
        if hits >= total * 0.6:
            return _("Muito bem! Você acertou %d de %d respostas. Confira abaixo as que faltaram.") % (hits, total)
        return _("Você acertou %d de %d respostas. Confira abaixo a classificação correta e tente de novo.") % (hits, total)

    def mg1_build_review():
        """Monta a revisão final (cada resposta, o que o jogador marcou e a certa)."""
        mg_review_clear()
        mg_review_group(_("Classificação do vírus da AIE"))

        if mg1_morph_index == MG1_MORPH_CORRECT:
            mg_review_add("ok", _("Morfologia: correta."), MG1_MORPH_NAME or "")
        else:
            why = MG1_MORPH_NAME or (_("A morfologia certa era a imagem nº %d das opções.") % (MG1_MORPH_CORRECT + 1))
            mg_review_add("bad", _("Morfologia: a imagem escolhida estava errada."), why)

        for i, cat in enumerate(MG1_CATEGORIES):
            name = MG1_CAT_NAMES[i]
            right = cat["options_debug"][cat["correct"]]
            now = cat["options_debug"][mg1_cat_indices[i]]
            if mg1_cat_indices[i] == cat["correct"]:
                mg_review_add("ok", "%s: %s" % (name, right))
            else:
                mg_review_add("bad", _("%s: você marcou \"%s\". O correto é \"%s\".") % (name, now, right))

    def mg1_click_morph():
        """Clique na imagem da esquerda: passa para a próxima morfologia."""
        global mg1_morph_index
        mg1_morph_index = (mg1_morph_index + 1) % len(MG1_MORPH_FILES)
        mg1_sfx("click")

    def mg1_click_category(i):
        """Clique em uma categoria: passa para a próxima opção dela (em ciclo)."""
        total = len(MG1_CATEGORIES[i]["files"])
        mg1_cat_indices[i] = (mg1_cat_indices[i] + 1) % total
        mg1_sfx("click")


## -----------------------------------------------------------------------
## 1.5) TELA DE INSTRUÇÕES
##    Uso: call screen minigame1_instructions
##    Modal: bloqueia qualquer clique no que estiver atrás até "Entendi".
## -----------------------------------------------------------------------
init python:

    # IMAGEM: minigame1/mg1_instructions_bg.png — fundo cheio da tela de
    # instruções. Tamanho final: 1920x1080 → exporte o PNG a 960x540.
    MG1_INSTR_BG = mg1_art("mg1_instructions_bg.png", (1920, 1080),
                            "FUNDO: instruções\n(mg1_instructions_bg.png)", "#2a2418")

    # IMAGEM: minigame1/mg1_instructions_panel.png — moldura do texto de regras,
    # sem texto (o texto é escrito pelo jogo, centralizado em (960, 490), com
    # até 1000 px de largura). CANVAS INTEIRO 960x540, moldura já na posição
    # (o retângulo (360, 190, 1200, 600) só posiciona o placeholder).
    MG1_INSTR_PANEL = mg1_full_art("mg1_instructions_panel.png", (360, 190, 1200, 600),
                                   "MOLDURA DE TEXTO\n(mg1_instructions_panel.png)", "#4a3a20")

    # IMAGEM: minigame1/mg1_close_idle.png e mg1_close_hover.png — botão
    # "Entendi" (texto desenhado). CANVAS INTEIRO 960x540, botão já na posição
    # (o retângulo (840, 860, 240, 80) só posiciona o placeholder).
    MG1_CLOSE_IDLE = mg1_full_art("mg1_close_idle.png", (840, 860, 240, 80), "ENTENDI\n(mg1_close_idle.png)", "#3a5a3a")
    MG1_CLOSE_HOVER = mg1_full_art("mg1_close_hover.png", (840, 860, 240, 80), "ENTENDI\n(mg1_close_hover.png)", "#4f7a4f")

    # Miniatura da tela do jogo para o tutorial: a MESMA arte (fundo, morfologia e
    # opções), no estado inicial (respostas ERRADAS, para não entregar a resposta),
    # reduzida a 40%.
    _mi = 0 if MG1_MORPH_CORRECT != 0 else 1
    _layers = [MG1_BG, MG1_MORPH_ART[_mi]]
    for _row, _cat in enumerate(MG1_CATEGORIES):
        _layers.append(MG1_CATEGORY_ART[_row][0 if _cat["correct"] != 0 else 1])
    _layers.append(MG1_CONCLUDE_IDLE)
    MG1_TUTORIAL_PREVIEW = mg_tut_preview(_layers)

style mg1_instructions_text:
    text_align 0.5
    color MG_INSTR_TEXT_COLOR
    size 30
    xsize 1000


screen minigame1_instructions():

    use mg_tutorial(MG1_INSTR_BG,
        _("Monte a classificação do vírus da Anemia Infecciosa Equina"),
        MG1_TUTORIAL_PREVIEW,
        [(659, 496), (1377, 520), (1377, 972)],
        [_("Clique na imagem do vírus para trocar a morfologia."),
         _("Clique em cada linha do livro (ordem, família, gênero...) para trocar a opção."),
         _("Quando achar que está tudo certo, clique em CONCLUIR. Não há tempo limite.")],
        _("No final você vê o que acertou e errou, com a resposta certa e a explicação, e pode jogar de novo. Cada resposta certa vale 10 pontos."),
        MG1_CLOSE_IDLE, MG1_CLOSE_HOVER)


## -----------------------------------------------------------------------
## 2) TELA DO MINIGAME
## -----------------------------------------------------------------------
screen minigame1_gameplay():

    modal True  # bloqueia qualquer interação com o que estiver atrás

    # Fundo cheio
    add MG1_BG

    # ---- Painel de título / objetivo (canto superior esquerdo) ----------
    # Se a sua arte do painel já tiver o texto desenhado, apague os 2 textos abaixo.
    add MG1_TITLE_PANEL
    text _("1 - TAXONOMIA E IDENTIFICAÇÃO DO VÍRUS"):
        xpos 90
        ypos 65
        size 34
        color "#ffffff"
    text _("Complete todas as características corretas do vírus da AIE."):
        xpos 90
        ypos 135
        size 24
        color "#ffffff"
        xmaximum 760

    # ---- Página esquerda: morfologia (clique para trocar) ---------------
    button:
        pos MG1_MORPH_POS
        xysize MG1_MORPH_SIZE
        background None
        focus_mask True  # só pixels coloridos respondem (útil se a PNG tiver áreas transparentes)
        action Function(mg1_click_morph)
        hovered Function(mg1_sfx, "hover")
        add MG1_MORPH_ART[mg1_morph_index]

    # Posição própria (fixa), já que a morfologia agora é tela cheia e não dá
    # mais pra calcular esta dica "logo abaixo" da imagem. Ajuste livremente.
    text _("Clique na imagem para trocar a morfologia"):
        xpos 260
        ypos 980
        size 24
        color "#ffffff"
        outlines [(3, "#2a1a0c", 0, 0)]

    # ---- Página direita: categorias taxonômicas -------------------------
    for i, cat in enumerate(MG1_CATEGORIES):

        $ row_y = MG1_ROWS_Y0 + i * MG1_ROWS_STEP

        # (O nome da categoria já está desenhado no fundo — o jogo não escreve.)
        # Botão de CANVAS INTEIRO que mostra a imagem da opção atual (já com o
        # texto desenhado nela, na posição da linha); cada clique avança para a
        # próxima opção, em ciclo — igual à morfologia.
        button:
            xysize (1920, 1080)
            background None
            focus_mask True  # só pixels opacos da arte respondem ao clique
            action Function(mg1_click_category, i)
            hovered Function(mg1_sfx, "hover")
            add MG1_CATEGORY_ART[i][mg1_cat_indices[i]]

    # ---- Concluir: o jogador decide quando terminou ---------------------
    imagebutton:
        idle MG1_CONCLUDE_IDLE
        hover MG1_CONCLUDE_HOVER
        focus_mask True
        action [Function(mg1_sfx, "click"), Return(True)]
        hovered Function(mg1_sfx, "hover")


## -----------------------------------------------------------------------
## 3) LABEL DO GAMEPLAY (motor do minigame em si)
## -----------------------------------------------------------------------
label minigame_1_gameplay:

    $ quick_menu = False       # esconde os botões rápidos do rodapé durante o minigame
    $ renpy.block_rollback()   # impede que o rollback (roda do mouse) bagunce o estado
    $ mg1_reset()              # sorteia o estado inicial (permite rejogar do zero)

    scene black
    call screen minigame1_gameplay   # só retorna quando o jogador clica em CONCLUIR
    $ mg1_build_review()

    $ quick_menu = True
    return


## -----------------------------------------------------------------------
## 4) PONTO DE ENTRADA (chamado pelo roadmap.rpy: "call expression 'minigame_1_entry'")
##    Mostra as instruções, roda o gameplay e avisa o mapa que terminou.
## -----------------------------------------------------------------------
label minigame_1_entry:

    call screen minigame1_instructions

    $ mg_again = True
    while mg_again:
        call minigame_1_gameplay from _mg1_gameplay_call

        $ mg_report_score(1, mg1_score(), MG1_MAX_SCORE)  # pontuação máxima = medalha (definido em progress.rpy)
        $ mg_complete(1)  # marca o minigame 1 como concluído e libera o 2

        call screen mg_result(mg1_score(), MG1_MAX_SCORE, mg1_verdict())
        $ mg_again = (_return == "replay")

    return
