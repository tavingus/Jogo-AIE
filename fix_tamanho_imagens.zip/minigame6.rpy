################################################################################
# MINIGAME6.RPY
# Minigame 6: "Transmissão por vetores" — clicar nas moscas hematófagas
#
# Como funciona:
#   - O cavalo fica parado no centro da tela (parte do fundo).
#   - As moscas aparecem UMA de cada vez, voando de fora da tela (de uma
#     borda aleatória) até um ponto de pouso perto do cavalo. Lá, ficam
#     PARADAS por um tempo e então somem sozinhas.
#   - Cada mosca tem uma "atitude certa": as HEMATÓFAGAS precisam ser
#     CLICADAS (a diferença visual entre elas é feita na própria arte, sem
#     texto); as SEM RISCO precisam ser IGNORADAS.
#   - Fazer a coisa certa (clicar na hematófaga, ou deixar a sem risco sumir
#     sozinha): +pontos. Fazer a coisa errada (deixar a hematófaga picar sem
#     clicar, ou clicar numa sem risco à toa): -pontos (nunca passa de 0).
#   - Acaba depois que um número fixo de moscas já apareceu.
#
# Pontuação (ver roadmap.rpy para o sistema de medalhas):
#   Tirar a pontuação máxima = acertar TODAS as moscas certas e nunca clicar
#   numa errada. "mg_report_score(6, pontos, MG6_MAX_SCORE)" registra o
#   placar e concede a medalha automaticamente quando for o caso.
#
# Este arquivo contém: dados/configuração, lógica, tela de instruções, tela
# do gameplay e o "label minigame_6_entry" — chamado pelo roadmap.rpy.
################################################################################


## -----------------------------------------------------------------------
## 1) CONFIGURAÇÃO, DADOS E ARTE
## -----------------------------------------------------------------------
init python:

    MG6_ART_DIR = "images/minigame6/"
    MG6_ZOOM = 2.0  # mesmo esquema de pixel art do resto do jogo

    def mg6_art(filename, size, label, color):
        """Imagem real (ampliada 2x, nearest neighbor) se o arquivo existir,
        senão um retângulo colorido com texto no tamanho final indicado."""
        path = MG6_ART_DIR + filename
        if renpy.loadable(path):
            return mg_canvas_art(path)
        return Fixed(
            Solid(color, xysize=size),
            Text(label, size=24, color="#ffffff", xalign=0.5, yalign=0.5,
                 text_align=0.5, xmaximum=size[0] - 16),
            xysize=size,
        )

    # IMAGEM: minigame6/mg6_bg.png — fundo cheio (cenário + cavalo já desenhado
    # no centro). Tamanho final: 1920x1080 → exporte o PNG a 960x540.
    MG6_BG = mg6_art("mg6_bg.png", (1920, 1080), "FUNDO: cavalo no centro\n(mg6_bg.png)", "#3a4a2a")

    # IMAGEM (opcional): minigame6/mg6_cavalo.png — o cavalo pastando (visão 3/4),
    # no CENTRO, em canvas inteiro 960x540 com fundo transparente. Se existir,
    # o mg6_bg.png deve ser só o cenário (sem cavalo). Se não existir, vale o
    # esquema antigo (cavalo já desenhado dentro do mg6_bg.png).
    MG6_HORSE_REAL = renpy.loadable(MG6_ART_DIR + "mg6_cavalo.png")
    MG6_HORSE = mg6_art("mg6_cavalo.png", (1920, 1080), "", "#00000000")

    # IMAGEM (opcional): minigame6/mg6_cavalo_picada.png — o cavalo SURPRESO com
    # a picada (mesma posição e tamanho do mg6_cavalo.png, canvas 960x540,
    # fundo transparente). Aparece por MG6_BITE_TIME segundos quando uma mosca
    # hematófaga some sem ser clicada ("picou o cavalo").
    MG6_HORSE_BITE_REAL = renpy.loadable(MG6_ART_DIR + "mg6_cavalo_picada.png")
    MG6_HORSE_BITE = mg6_art("mg6_cavalo_picada.png", (1920, 1080), "", "#00000000")
    MG6_BITE_TIME = 0.7

    # Tamanho de exibição de cada mosca. Tamanho final: 140x140 → exporte
    # cada PNG a 70x70.
    MG6_FLY_SIZE = (140, 140)

    # IMAGEM: minigame6/fly_correct_1.png, fly_correct_2.png — moscas
    # HEMATÓFAGAS (as que pontuam ao clicar). Use 2+ variações visuais.
    MG6_CORRECT_FILES = ["fly_correct_1.png", "fly_correct_2.png"]

    # IMAGEM: minigame6/fly_wrong_1.png, fly_wrong_2.png — moscas SEM risco
    # (clicar nelas penaliza). A diferença visual das hematófagas deve estar
    # na própria arte (cor, formato etc.), sem nenhum texto desenhado pelo jogo.
    MG6_WRONG_FILES = ["fly_wrong_1.png", "fly_wrong_2.png"]

    def mg6_fly_colors(ftype):
        return "#8a2c2c" if ftype == "correct" else "#4a4a4a"

    def mg6_fly_art(ftype, filename):
        label = "MOSCA %s\n(%s)" % ("CORRETA" if ftype == "correct" else "ERRADA", filename)
        return mg6_art(filename, MG6_FLY_SIZE, label, mg6_fly_colors(ftype))

    # Área (x_min, y_min, x_max, y_max) onde as moscas pousam, perto do
    # cavalo — ajuste para cobrir a região certa na sua arte de fundo.
    # (elas começam fora da tela e voam até um ponto sorteado aqui dentro)
    MG6_SPAWN_AREA = (520, 260, 1400, 820)

    # ---- Regras da partida ------------------------------------------------
    MG6_TOTAL_FLIES = 12         # quantas moscas aparecem, ao todo, numa partida
    MG6_CORRECT_COUNT = 8        # quantas dessas são hematófagas (o resto, "erradas")
    MG6_FLY_TRAVEL_TIME = 1.0    # segundos voando da borda até o ponto de pouso
    MG6_FLY_LANDED_TIME = 2.0    # segundos PARADA no pouso antes de sumir sozinha
    # tempo total que a mosca fica na tela (voando + pousada), usado pelo timer:
    MG6_FLY_TOTAL_TIME = MG6_FLY_TRAVEL_TIME + MG6_FLY_LANDED_TIME
    MG6_END_DELAY = 2.0          # segundos mostrando o placar final antes de voltar ao mapa

    # A "atitude certa" para cada mosca:
    #   - hematófaga (correct): tem que CLICAR nela. Clicar = acerto. Deixar
    #     sumir sozinha (ela "pousou e picou" sem ser notada) = erro.
    #   - sem risco (wrong): tem que IGNORAR. Deixar sumir sozinha = acerto.
    #     Clicar nela (sem necessidade) = erro.
    # Ou seja: toda mosca rende pontos ou desconta, dependendo só de você ter
    # feito a coisa certa com ela — clicando ou não clicando.
    MG6_POINTS_CORRECT = 10  # pontos por ter feito a atitude certa com a mosca
    MG6_POINTS_WRONG = -5    # pontos por ter feito a atitude errada (placar nunca < 0)

    # Pontuação máxima possível: acertar a atitude certa nas 12 moscas.
    MG6_MAX_SCORE = MG6_TOTAL_FLIES * MG6_POINTS_CORRECT

    # ---- Efeitos sonoros (tocam só se o arquivo existir) ------------------
    def mg6_sfx(kind):
        # AUDIO: audio/sfx_hover.ogg, audio/sfx_click.ogg (já usados em outras telas)
        # AUDIO: audio/sfx_correct.ogg, audio/sfx_wrong.ogg (opcionais, específicos deste minigame)
        files = {
            "hover": "audio/sfx_hover.ogg",
            "click": "audio/sfx_click.ogg",
            "correct": "audio/sfx_correct.ogg",
            "wrong": "audio/sfx_wrong.ogg",
            "bite": "audio/sfx_horse_angry.ogg",
        }
        path = files.get(kind)
        if path and renpy.loadable(path):
            renpy.sound.play(path)


## Estado da partida (guardado no save / rollback)
default mg6_flies_sequence = []  # ordem embaralhada ("correct"/"wrong") desta partida
default mg6_fly_index = 0        # quantas moscas já apareceram (inclui a atual)
default mg6_score = 0            # pontuação atual
default mg6_current_fly = None   # dict da mosca na tela agora: type/file/posições
default mg6_stats = {}           # contagens da partida (para a revisão final)


init python:

    def mg6_offscreen_point(margin=220):
        """Um ponto fora da tela (1920x1080), numa borda aleatória — de onde
        a mosca começa a voar até o ponto de pouso perto do cavalo."""
        edge = renpy.random.choice(["left", "right", "top", "bottom"])
        if edge == "left":
            return (-margin, renpy.random.randint(0, 1080))
        elif edge == "right":
            return (1920 + margin, renpy.random.randint(0, 1080))
        elif edge == "top":
            return (renpy.random.randint(0, 1920), -margin)
        else:
            return (renpy.random.randint(0, 1920), 1080 + margin)

    def mg6_reset():
        """Prepara uma nova partida: embaralha a ordem das moscas."""
        seq = (["correct"] * MG6_CORRECT_COUNT) + (["wrong"] * (MG6_TOTAL_FLIES - MG6_CORRECT_COUNT))
        renpy.random.shuffle(seq)

        store.mg6_flies_sequence = seq
        store.mg6_fly_index = 0
        store.mg6_score = 0
        store.mg6_current_fly = None
        store.mg6_stats = {"hit_bug": 0, "miss_bug": 0, "ignored_ok": 0, "clicked_bad": 0}
        mg_review_clear()

    def mg6_next_fly():
        """Prepara a próxima mosca da lista, em posição aleatória. Devolve
        False quando não há mais moscas (fim da partida)."""
        if store.mg6_fly_index >= len(store.mg6_flies_sequence):
            store.mg6_current_fly = None
            return False

        ftype = store.mg6_flies_sequence[store.mg6_fly_index]
        store.mg6_fly_index += 1

        # Ponto de pouso (perto do cavalo) — onde a mosca fica parada e clicável
        # depois de chegar.
        x_min, y_min, x_max, y_max = MG6_SPAWN_AREA
        target_x = renpy.random.randint(x_min, max(x_min, x_max - MG6_FLY_SIZE[0]))
        target_y = renpy.random.randint(y_min, max(y_min, y_max - MG6_FLY_SIZE[1]))

        # Ponto de partida, fora da tela, numa borda aleatória.
        start_x, start_y = mg6_offscreen_point()

        art_file = renpy.random.choice(MG6_CORRECT_FILES if ftype == "correct" else MG6_WRONG_FILES)

        store.mg6_current_fly = {
            "type": ftype,
            "file": art_file,
            "start_x": start_x,
            "start_y": start_y,
            "target_x": target_x,
            "target_y": target_y,
        }
        return True

    def mg6_resolve_fly(result):
        """Aplica a pontuação da mosca atual e toca o som correspondente.
        result = "clicked" (o jogador clicou) ou "expired" (sumiu sozinha).
          - Hematófaga clicada = acerto. Não clicada (picou o cavalo) = erro.
          - Sem risco ignorada (sumiu sozinha) = acerto. Clicada = erro."""
        if store.mg6_current_fly["type"] == "correct":
            acted_correctly = (result == "clicked")
        else:
            acted_correctly = (result == "expired")

        kind = store.mg6_current_fly["type"]
        if kind == "correct":
            store.mg6_stats["hit_bug" if acted_correctly else "miss_bug"] += 1
        else:
            store.mg6_stats["ignored_ok" if acted_correctly else "clicked_bad"] += 1

        if acted_correctly:
            store.mg6_score += MG6_POINTS_CORRECT
            mg6_sfx("correct")
        else:
            store.mg6_score = max(0, store.mg6_score + MG6_POINTS_WRONG)
            mg6_sfx("wrong")


init python:

    def mg6_verdict():
        """Frase final conforme o desempenho."""
        ratio = float(store.mg6_score) / max(1, MG6_MAX_SCORE)
        if ratio >= 1.0:
            return _("Perfeito! Nenhuma mosca hematófaga escapou e nenhuma inofensiva foi atacada.")
        elif ratio >= 0.6:
            return _("Bom trabalho! Mas algumas moscas foram tratadas do jeito errado.")
        else:
            return _("Revise como identificar as moscas hematófagas e tente de novo.")

    def mg6_build_review():
        """Revisão final: o que o jogador fez com cada tipo de mosca."""
        st = store.mg6_stats
        n_bug = MG6_CORRECT_COUNT
        n_ok = MG6_TOTAL_FLIES - MG6_CORRECT_COUNT
        mg_review_clear()

        mg_review_group(_("Moscas hematófagas (picam e podem transmitir o vírus)"))
        if st["hit_bug"]:
            mg_review_add("ok", _("Você clicou em %d de %d moscas hematófagas.") % (st["hit_bug"], n_bug),
                          _("Certo: elas precisam ser afastadas antes de picar o cavalo."))
        if st["miss_bug"]:
            mg_review_add("bad", _("%d moscas hematófagas escaparam e picaram o cavalo.") % st["miss_bug"],
                          _("Cada picada pode levar o vírus da AIE de um animal para outro."))

        mg_review_group(_("Moscas inofensivas (não picam)"))
        if st["ignored_ok"]:
            mg_review_add("ok", _("Você ignorou %d de %d moscas inofensivas.") % (st["ignored_ok"], n_ok),
                          _("Certo: elas não oferecem risco para o cavalo."))
        if st["clicked_bad"]:
            mg_review_add("bad", _("Você clicou em %d moscas inofensivas por engano.") % st["clicked_bad"],
                          _("Clicar nelas tira pontos: o desafio é reconhecer quais realmente picam."))

        mg_review_note(_("Na AIE, a transmissão ocorre principalmente pelo sangue, por insetos hematófagos (como mutucas e moscas-dos-estábulos) e por agulhas ou instrumentos contaminados."))


## -----------------------------------------------------------------------
## 2) TELA DE INSTRUÇÕES
##    Uso: call screen minigame6_instructions
## -----------------------------------------------------------------------
init python:

    # IMAGEM: minigame6/mg6_instructions_bg.png — fundo cheio das instruções.
    # Tamanho final: 1920x1080 → exporte o PNG a 960x540.
    MG6_INSTR_BG = mg6_art("mg6_instructions_bg.png", (1920, 1080),
                            "FUNDO: instruções\n(mg6_instructions_bg.png)", "#2a2418")

    # IMAGEM: minigame6/mg6_instructions_panel.png — moldura do texto de regras.
    # Tamanho final: 1200x600 → exporte o PNG a 600x300.
    MG6_INSTR_PANEL = mg6_art("mg6_instructions_panel.png", (1200, 600),
                               "MOLDURA DE TEXTO\n(mg6_instructions_panel.png)", "#4a3a20")

init python:

    MG6_CLOSE_IDLE = mg6_art("mg6_close_idle.png", (240, 80), "ENTENDI\n(mg6_close_idle.png)", "#3a5a3a")
    MG6_CLOSE_HOVER = mg6_art("mg6_close_hover.png", (240, 80), "ENTENDI\n(mg6_close_hover.png)", "#4f7a4f")

    # Miniatura para o tutorial: o cenário com as duas moscas, no tamanho do jogo
    _l = [MG6_BG]
    if MG6_HORSE_REAL:
        _l.append(MG6_HORSE)
    _l.append(mg_tut_at(mg6_fly_art("correct", MG6_CORRECT_FILES[0]), 780, 430))
    _l.append(mg_tut_at(mg6_fly_art("wrong", MG6_WRONG_FILES[0]), 1080, 560))
    _l.append(mg_tut_text(_("Pontos: 0"), 60, 40, size=36))
    _l.append(mg_tut_text("3/%d" % MG6_TOTAL_FLIES, 1700, 40, size=30))
    MG6_TUTORIAL_PREVIEW = mg_tut_preview(_l)

style mg6_instructions_text:
    xalign 0.5
    yalign 0.5
    text_align 0.5
    color MG_INSTR_TEXT_COLOR
    size 30
    xsize 1000


screen minigame6_instructions():

    use mg_tutorial(MG6_INSTR_BG,
        _("Moscas estão rondando o cavalo!"),
        MG6_TUTORIAL_PREVIEW,
        [(850, 500), (1150, 630), (1760, 60)],
        [_("HEMATÓFAGA (pica e pode transmitir a doença): CLIQUE nela antes que suma."),
         _("INOFENSIVA (não pica): IGNORE. Clicar nela tira pontos."),
         _("O contador mostra quantas moscas já apareceram, de %d no total.") % MG6_TOTAL_FLIES],
        _("Se uma hematófaga escapar, ela pica o cavalo e você perde pontos. No final você vê o que acertou e errou, e pode jogar de novo."),
        MG6_CLOSE_IDLE, MG6_CLOSE_HOVER, (0.5, 0.85))


## -----------------------------------------------------------------------
## 2.5) MOVIMENTO DA MOSCA (de fora da tela até o ponto de pouso)
## -----------------------------------------------------------------------

transform mg6_fly_move(start_x, start_y, target_x, target_y, duration):
    pos (start_x, start_y)
    linear duration pos (target_x, target_y)


## -----------------------------------------------------------------------
## 3) TELAS DO GAMEPLAY
##    Cada mosca é uma chamada própria de "call screen minigame6_fly". O prazo
##    dela é o timer DESTA tela: como a tela é recriada a cada mosca, o timer
##    sempre começa do zero e dispara sozinho. (Antes, um timer único e fixo
##    dentro da mesma tela acabava cacheado pelo Ren'Py e a mosca só sumia ao
##    clicar.)
## -----------------------------------------------------------------------

# Cenário + cavalo (pastando ou surpreso com a picada)
screen mg6_scene(bitten=False):

    add MG6_BG

    if MG6_HORSE_REAL:
        if bitten and MG6_HORSE_BITE_REAL:
            add MG6_HORSE_BITE
        else:
            add MG6_HORSE


# HUD: pontuação atual e progresso (quantas moscas já passaram)
screen minigame6_hud():

    text _("Pontos: [mg6_score]"):
        xpos 60
        ypos 40
        size 36
        color "#ffffff"
        outlines [(3, "#2a1a0c", 0, 0)]

    text "[mg6_fly_index]/[MG6_TOTAL_FLIES]":
        xalign 0.97
        ypos 40
        size 30
        color "#ffffff"
        outlines [(3, "#2a1a0c", 0, 0)]


# Uma mosca. Retorna "clicked" se o jogador clicou, ou "expired" quando o
# tempo dela (voo + pousada) acaba.
screen minigame6_fly():

    modal True

    use mg6_scene

    use minigame6_hud

    $ fly = mg6_current_fly

    button:
        # A animação dura só o tempo de VOO — ao terminar, a mosca fica
        # parada no ponto de pouso (comportamento padrão do ATL: sem mais
        # instruções, ele simplesmente mantém a última posição).
        at mg6_fly_move(fly["start_x"], fly["start_y"], fly["target_x"], fly["target_y"], MG6_FLY_TRAVEL_TIME)
        xysize MG6_FLY_SIZE
        background None
        focus_mask True  # só pixels coloridos da mosca respondem ao clique
        action Return("clicked")
        add mg6_fly_art(fly["type"], fly["file"])

    timer MG6_FLY_TOTAL_TIME action Return("expired")


# Reação do cavalo à picada (toca rapidinho e volta ao jogo)
screen minigame6_bitten():

    modal True

    use mg6_scene(bitten=True)

    use minigame6_hud

    timer MG6_BITE_TIME action Return(True)



## -----------------------------------------------------------------------
## 4) LABELS: GAMEPLAY E PONTO DE ENTRADA
## -----------------------------------------------------------------------
label minigame_6_gameplay:

    $ quick_menu = False
    $ renpy.block_rollback()
    $ mg6_reset()

    scene black

    # Uma mosca por vez, até acabarem
    while mg6_next_fly():
        call screen minigame6_fly
        $ fly_result = _return
        $ was_bitten = (fly_result == "expired" and mg6_current_fly["type"] == "correct")
        $ mg6_resolve_fly(fly_result)
        if was_bitten and MG6_HORSE_BITE_REAL:
            $ mg6_sfx("bite")
            call screen minigame6_bitten

    $ mg6_build_review()

    $ quick_menu = True
    return


label minigame_6_entry:

    call screen minigame6_instructions

    $ mg_again = True
    while mg_again:
        call minigame_6_gameplay from _mg6_gameplay_call

        $ mg_report_score(6, mg6_score, MG6_MAX_SCORE)  # registra o placar e a medalha, se for o caso
        $ mg_complete(6)                                 # marca como concluído e libera o próximo

        call screen mg_result(mg6_score, MG6_MAX_SCORE, mg6_verdict())
        $ mg_again = (_return == "replay")

    return
